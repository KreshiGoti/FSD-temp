import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Navigation.css';

const Navigation = () => {
  const location = useLocation();
  
  // Show navigation on all pages
  const isLoggedIn = true; // This would come from your auth context/state in a real app

  // Main navigation for all pages
  return (
    <nav className="main-nav">
      <div className="nav-container">
        <div className="nav-brand">
          <Link to="/" className="brand-logo">
            <div className="logo-icon">🎉</div>
            <span className="brand-text">EventHub</span>
          </Link>
        </div>
        <div className="nav-elements">
          <div className="nav-menu">
            <Link to="/events" className="nav-link">Events</Link>
            <a href="#about" className="nav-link">About</a>
            <a href="#contact" className="nav-link">Contact</a>
          </div>
          <div className="nav-actions">
            {isLoggedIn ? (
              <>
                <Link to="/profile-settings" className="profile-icon-wrapper">
                  <div className="profile-icon">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 12C14.7614 12 17 9.76142 17 7C17 4.23858 14.7614 2 12 2C9.23858 2 7 4.23858 7 7C7 9.76142 9.23858 12 12 12Z" fill="#4A5568"/>
                      <path d="M12 14.5C6.99 14.5 2.91 17.86 2.91 22C2.91 22.28 3.13 22.5 3.41 22.5H20.59C20.87 22.5 21.09 22.28 21.09 22C21.09 17.86 17.01 14.5 12 14.5Z" fill="#4A5568"/>
                    </svg>
                  </div>
                </Link>
                <div className="profile-name-wrapper">
                  <Link to="/admin-dashboard" className="profile-name">John Doe</Link>
                </div>
              </>
            ) : (
              <>
                <Link to="/signup" className="btn btn-outline">Sign Up</Link>
                <Link to="/login" className="btn btn-primary">Log In</Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
