import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Signup.css';

const Signup = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData);
    console.log('Signup data:', data);
  };

  return (
    <div className="signup-page">
      <div className="signup-hero">
        <h1 className="signup-title">Create Your Account</h1>
        <p className="signup-subtitle">Join our community and discover amazing events</p>
      </div>

      <main className="signup-container">
        <div className="signup-card">
          <div className="card-title">Sign Up</div>

          <form onSubmit={handleSubmit} className="signup-form">
            <div className="form-group">
              <label htmlFor="name">Full Name</label>
              <div className="input-wrapper">
                <input
                  type="text"
                  id="name"
                  name="name"
                  placeholder="Enter your full name"
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="email">Email Address</label>
              <div className="input-wrapper">
                <input
                  type="email"
                  id="email"
                  name="email"
                  placeholder="Enter your email"
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="password">Password</label>
              <div className="input-wrapper">
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  name="password"
                  placeholder="Create a password"
                  minLength="6"
                  required
                />
                <button type="button" className="eye-btn" onClick={() => setShowPassword(v => !v)} aria-label="Toggle password visibility">
                </button>
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="confirm">Confirm Password</label>
              <div className="input-wrapper">
                <input
                  type={showConfirm ? 'text' : 'password'}
                  id="confirm"
                  name="confirm"
                  placeholder="Confirm your password"
                  minLength="6"
                  required
                />
                <button type="button" className="eye-btn" onClick={() => setShowConfirm(v => !v)} aria-label="Toggle confirm password visibility">
                </button>
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="accountType">Account Type</label>
              <div className="select-wrapper">
                <select id="accountType" name="accountType" defaultValue="user">
                  <option value="user">User (Event Attendee)</option>
                  <option value="organizer">Organizer</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div className="helper-text">User accounts can browse and register for events</div>
            </div>

            <button type="submit" className="primary-btn">Create User Account</button>

            <div className="divider">
              <span>Already have an account?</span>
            </div>

            <Link to="/login" className="secondary-btn">Login</Link>
          </form>
        </div>
      </main>
    </div>
  );
};

export default Signup;
