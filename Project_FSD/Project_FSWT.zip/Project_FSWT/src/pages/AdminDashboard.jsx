import React, { useState } from 'react';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('past');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);

  return (
    <div className="admin-dashboard">
      <section className="admin-events-header">
        <div className="admin-events-header-inner">
          <div>
            <h1 className="admin-events-title">Events Management</h1>
            <p className="admin-events-subtitle">Create and manage campus events</p>
          </div>
          <button className="create-event-btn" onClick={openModal}>
            <span className="plus">+</span> Create Event
          </button>
          </div>
        <div className="admin-tabs">
          <button className={`admin-tab ${activeTab==='live'?'active':''}`} onClick={()=>setActiveTab('live')}>Live Events</button>
          <button className={`admin-tab ${activeTab==='upcoming'?'active':''}`} onClick={()=>setActiveTab('upcoming')}>Upcoming Events</button>
          <button className={`admin-tab ${activeTab==='past'?'active':''}`} onClick={()=>setActiveTab('past')}>Past Events</button>
        </div>
      </section>

      <section className="admin-table-section">
        <div className="admin-table">
          <div className="admin-table-row admin-table-head">
            <div className="col event">Event</div>
            <div className="col date">Date</div>
            <div className="col location">Location</div>
            <div className="col participants">Participants</div>
            <div className="col status">Status</div>
            <div className="col actions">Actions</div>
                </div>
          <div className="admin-table-row">
            <div className="col event">
              <div className="avatar">ML</div>
              <div>
                <div className="event-name">Machine Learning Expert Talk</div>
                <div className="event-type">workshop</div>
                </div>
              </div>
            <div className="col date">2025-09-10 10:15:00</div>
            <div className="col location">Seminar Hall</div>
            <div className="col participants">120</div>
            <div className="col status"><span className="badge">Past</span></div>
            <div className="col actions"><button className="link">Edit</button><button className="link danger">Delete</button></div>
          </div>
        </div>
      </section>

      {isModalOpen && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal" onClick={(e)=>e.stopPropagation()}>
            <div className="modal-header">
              <div className="modal-title">Create New Event</div>
              <button className="modal-close" onClick={closeModal}>×</button>
            </div>
            <form className="event-form">
              <div className="form-row">
                <div className="form-group">
                  <label>Event Title</label>
                  <input type="text" placeholder="Enter event title" />
            </div>
                <div className="form-group">
                  <label>Category</label>
                  <select defaultValue="">
                    <option value="" disabled>Select category</option>
                    <option>Technology</option>
                    <option>Business</option>
                    <option>Entertainment</option>
                  </select>
            </div>
          </div>
              <div className="form-group">
                <label>Description</label>
                <textarea placeholder="Enter event description"></textarea>
            </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Date</label>
                  <input type="date" />
            </div>
                <div className="form-group">
                  <label>Time</label>
                  <input type="time" />
          </div>
        </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Location</label>
                  <input type="text" placeholder="Enter event location" />
                </div>
                <div className="form-group">
                  <label>Capacity</label>
                  <input type="number" placeholder="Enter maximum capacity" />
                    </div>
                  </div>
              <div className="form-group">
                <label>Event Image</label>
                <div className="dropzone">Drag and drop an image or click to browse
                  <div className="hint">Recommended size: 800x400 pixels</div>
                </div>
              </div>
              <div className="form-footer">
                <button type="button" className="btn secondary" onClick={closeModal}>Cancel</button>
                <button type="button" className="btn primary">Create Event</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
