import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../components/ProfileSettings.css';

const ProfileSettings = () => {
  const [formData, setFormData] = useState({
    fullName: 'John Doe',
    email: 'admin@demo.com',
    phone: '+1 (555) 123-4567'
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  return (
    <div className="profile-settings-container">
      <div className="profile-header">
        <Link to="/dashboard" className="back-link">
          <span>←</span> Back to Dashboard
        </Link>
        <div className="header-content">
          <h1>Profile Settings</h1>
          <p className="subtitle">Manage your account information</p>
        </div>
      </div>

      <div className="profile-content">
        {/* User Card */}
        <div className="user-card">
          <div className="user-avatar">
            <div className="avatar-icon">JD</div>
          </div>
          <div className="user-info">
            <h2>John Doe</h2>
            <p className="user-email">admin@demo.com</p>
            <span className="user-role">User</span>
          </div>
        </div>

        {/* Account Status */}
        <div className="settings-section">
          <h3>Account Status</h3>
          <div className="status-grid">
            <div className="status-item">
              <span className="status-label">Account Type</span>
              <span className="status-value">Standard User</span>
            </div>
            <div className="status-item">
              <span className="status-label">Status</span>
              <span className="status-value status-active">Active</span>
            </div>
            <div className="status-item">
              <span className="status-label">Member Since</span>
              <span className="status-value">March 2024</span>
            </div>
          </div>
        </div>

        {/* Personal Information */}
        <div className="settings-section">
          <h3>Personal Information</h3>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor="fullName">Full Name</label>
              <input
                type="text"
                id="fullName"
                name="fullName"
                value={formData.fullName}
                onChange={handleChange}
                className="form-input"
              />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email Address</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="form-input"
              />
            </div>
            <div className="form-group">
              <label htmlFor="phone">Phone Number</label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="form-input"
              />
            </div>
            <div className="form-actions">
              <button type="button" className="btn btn-outline">Cancel</button>
              <button type="submit" className="btn btn-primary">Save Changes</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ProfileSettings;
